package com.example.fruitpal.dto;


import lombok.Getter;
import lombok.Setter;


/**
 * POJO to handle FruitPal transactions
 */
@Getter
@Setter
public class FruitPalDTO {

    private String commodity;
    private double price;
    private int volume;

}
