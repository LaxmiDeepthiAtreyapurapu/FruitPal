package com.example.fruitpal.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FruitPalJSONDTO {
    private String country;
    private String commodity;
    private double variableOverhead;
}
