package com.example.fruitpal;

import com.example.fruitpal.dto.FruitPalDTO;
import com.example.fruitpal.service.FruitPalServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;
import java.util.Scanner;

@SpringBootApplication
public class FruitpalApplication {

    @Autowired
    private static FruitPalServiceImpl fruitPalService;

    public static void main(String[] args) throws IOException {



        Scanner  scanner = new Scanner(System.in);
        String commodity = scanner.next();
        double price = scanner.nextDouble();
        int volume = scanner.nextInt();

        FruitPalDTO fruitPalDTO = fruitPalService.getFruitPalDTO(commodity, price, volume);

        // parse json file


       /* JacksonJsonParser jacksonJsonParser = new JacksonJsonParser();


        try(FileReader reader = new FileReader("third_party.json")){

           List<Object> fruitpalJsonObj = jacksonJsonParser.parseList(reader.toString());
           System.out.println(fruitpalJsonObj);

        }*/




        SpringApplication.run(FruitpalApplication.class, args);
    }

}
