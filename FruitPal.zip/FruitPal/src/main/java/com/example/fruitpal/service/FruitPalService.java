package com.example.fruitpal.service;

import com.example.fruitpal.dto.FruitPalDTO;

public interface FruitPalService {

    public FruitPalDTO getFruitPalDTO(String commodity, double price, int volume);
}
