package com.example.fruitpal.service;


import com.example.fruitpal.dto.FruitPalDTO;
import org.springframework.stereotype.Component;

@Component
public class FruitPalServiceImpl {


    /**
     * Method to get fruitpal object
     * @param commodity
     * @param price
     * @param volume
     * @return
     */
    public FruitPalDTO getFruitPalDTO(String commodity, double price, int volume){

        FruitPalDTO fruitPalDTO = new FruitPalDTO();
        fruitPalDTO.setCommodity(commodity);
        fruitPalDTO.setPrice(price);
        fruitPalDTO.setVolume(volume);

        return fruitPalDTO;

    }





}
